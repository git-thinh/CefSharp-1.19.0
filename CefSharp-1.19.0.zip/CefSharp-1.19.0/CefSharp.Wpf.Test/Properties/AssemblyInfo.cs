﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CefSharp.Wpf.Test")]
[assembly: AssemblyCompany("Anthony Taranto")]
[assembly: AssemblyProduct("CefSharp")]
[assembly: AssemblyCopyright("Copyright © 2012")]

[assembly: AssemblyVersion("1.19.0.*")]
[assembly: ComVisible(false)]
